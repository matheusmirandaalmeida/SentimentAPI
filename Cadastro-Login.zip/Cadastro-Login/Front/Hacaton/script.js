fetch("http://localhost:8080/auth/login", {
    method: "POST",
    headers: {
        "Content-Type": "application/json"
    },
    body: JSON.stringify({
        email: emailInput.value,
        senha: senhaInput.value
    })
})
.then(res => res.text())
.then(msg => alert(msg));

//cadastro
fetch("http://localhost:8080/auth/register", {
    method: "POST",
    headers: {
        "Content-Type": "application/json"
    },
    body: JSON.stringify({
        email: emailCadastro.value,
        senha: senhaCadastro.value
    })
})
.then(res => res.text())
.then(msg => alert(msg));
