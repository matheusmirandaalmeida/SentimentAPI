package br.com.hackaton.www.hacka.controller;

import br.com.hackaton.www.hacka.model.Usuario;
import br.com.hackaton.www.hacka.repository.UsuarioRepository;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "*") // permite acesso do frontend
public class Authcontroller {

    private final UsuarioRepository repository;

    public Authcontroller(UsuarioRepository repository) {
        this.repository = repository;
    }

    // CADASTRO
    @PostMapping("/register")
    public String cadastrar(@RequestBody Usuario usuario) {

        if (repository.findByEmail(usuario.getEmail()).isPresent()) {
            return "Usuário já existe";
        }

        repository.save(usuario);
        return "Cadastro realizado com sucesso";
    }

    // LOGIN
    @PostMapping("/login")
    public String login(@RequestBody Usuario usuario) {

        return repository.findByEmail(usuario.getEmail())
                .filter(u -> u.getSenha().equals(usuario.getSenha()))
                .map(u -> "Login realizado com sucesso")
                .orElse("Email ou senha inválidos");
    }
}
