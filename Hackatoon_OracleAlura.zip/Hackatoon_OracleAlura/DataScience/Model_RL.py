# Importando as variáveis do arquivo de tokenização
from Data_Tokening import X, Y, embedding_text

# Realizando a divisão dos dados com 80% usado para treino
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, test_size=0.20, stratify=Y
)

# Aplicando o embedding nos dados apenas depois de separar em treino e teste,
# para que os dados de treino estejam isolados dos dados de testes
import numpy as np  # Importando o numpy para converter a lista em um array
X_train = np.array(embedding_text(list(X_train)))

print("X treino\n", X_train.shape[0])
print("\nX testes\n", X_test.shape[0])

# Importando o modelo de Regressão Logística
from sklearn.linear_model import LogisticRegression

# Inicializando a primeira versão do modelo
LogReg_model = LogisticRegression(
    max_iter=1000,            # Necessário para convergir com embeddings
    class_weight='balanced',  # Importante para evitar viés de classe
    n_jobs=-1
)

# Treinamento do modelo
LogReg_model.fit(X_train, Y_train)
print("Treinamento finalizado")


# Fazendo o embedding dos dados de teste
X_test = np.array(embedding_text(list(X_test)))

# Pegando as previsões do modelo com os dados de teste
Y_prev = LogReg_model.predict(X_test)


# Validação cruzada do modelo
from sklearn.model_selection import cross_validate, StratifiedKFold

# Dividindo os dados para validar o modelo usando as métricas corretas
skf = StratifiedKFold(n_splits=10, shuffle=True)

# Modelo que será analisado
model = LogisticRegression(
    max_iter=1000,
    class_weight='balanced',
    n_jobs=-1
)

# Pegando embedding completo
X_emb = np.array(embedding_text(list(X)))

# Realizando a validação cruzada
cv_resultados = cross_validate(
    model,
    X_emb,
    Y,
    cv=skf,
    scoring=['accuracy', 'precision', 'recall', 'f1'],
    n_jobs=-1
)

# Printando resultados
for metric in cv_resultados:
    if metric.startswith('test_'):
        print(
            metric,
            f"média={np.mean(cv_resultados[metric]):.3f}",
            f"std={np.std(cv_resultados[metric]):.3f}"
        )


# Avaliando com a matriz de confusão
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt

# Criando a matriz
matriz_confusao = confusion_matrix(Y_test, Y_prev)

# Visualizando a matriz de confusão
visualizacao = ConfusionMatrixDisplay(
    matriz_confusao,
    display_labels=['Negativo', 'Positivo']
)
visualizacao.plot()
plt.show()


from sklearn.metrics import classification_report
print(classification_report(Y_test, Y_prev))

# Fazendo o modelo novamente, dessa vez com ajuste de hiperparâmetros
LogReg_model = LogisticRegression(
    max_iter=1000,
    class_weight='balanced',
    n_jobs=-1
)

# Grid de parâmetros (equivalente ao seu Grid do SVC)
param_grid = {
    'C': [0.01, 0.1, 1, 10],
    'solver': ['lbfgs', 'liblinear']
}

# Importando o GridSearchCV
from sklearn.model_selection import GridSearchCV

Best_LogReg = GridSearchCV(
    estimator=LogReg_model,  # Modelo
    param_grid=param_grid,   # Grid de parâmetros
    scoring='f1',            # Métrica principal
    cv=skf,                  # Validação cruzada
    verbose=True,
    n_jobs=-1
)

# Treinamento
Best_LogReg.fit(X_train, Y_train)

# Melhores parâmetros
print("\n\n Melhores parâmetros", Best_LogReg.best_params_)


# Novas previsões
Y_prev = Best_LogReg.predict(X_test)

# Criando a matriz
matriz_confusao = confusion_matrix(Y_test, Y_prev)

# Visualizando
visualizacao = ConfusionMatrixDisplay(
    matriz_confusao,
    display_labels=['Negativo', 'Positivo']
)
visualizacao.plot()
plt.show()
