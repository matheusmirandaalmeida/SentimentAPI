from Data_Tokening import embedding_text

#Salvando o modelo para ser usado depois usando pickle
import pickle
path = r'C:\Users\pedro\Desktop\Tech Journey\Hackatoon_OracleAlura\DataScience\Best_SVC.pkl'
#Carregando e testando o modelo
with open(path, 'rb') as f:
    Loaded_SVC = pickle.load(f)


#Criando comentario
Comentary = [
    "The office looks modern and the benefits sound attractive, however the lack of organization, poor communication, and constant stress slowly turn the job into a frustrating experience."
]
#I love the food, but my salary is very low and the management isn't good either.
#Even though the people are horrible, the food is amazing and I like how they treat new employees.
#The office looks modern and the benefits sound attractive, however the lack of organization, poor communication, and constant stress slowly turn the job into a frustrating experience.

#Embedding
Comentary = embedding_text(Comentary)
print(Comentary)
#Fazendo a previsão
Result = Loaded_SVC.predict(Comentary[:5])

print(Result)
pred_proba = Loaded_SVC.predict_proba(Comentary)
print("Probabilidades:", pred_proba)



# Carregando o modelo salvo RL
path2 = r'C:\Users\pedro\Desktop\Tech Journey\Hackatoon_OracleAlura\DataScience\Best_LogReg.pkl'
with open(path2, 'rb') as f:
    Loaded_LogReg = pickle.load(f)


# Fazendo a previsão
pred_class = Loaded_LogReg.predict(Comentary)
pred_proba = Loaded_LogReg.predict_proba(Comentary)

print("Classe prevista RL:", pred_class)
print("Probabilidades RL:", pred_proba)